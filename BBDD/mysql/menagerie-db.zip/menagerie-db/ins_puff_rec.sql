INSERT INTO pet VALUES ('Puffball','Diane','hamster','f','1999-03-30',NULL);
